# Printf

```@docs
Printf.@printf
Printf.@sprintf
```
