# Memory-mapped I/O

```@docs
Mmap.Anonymous
Mmap.mmap
Mmap.sync!
```
