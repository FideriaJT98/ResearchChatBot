# **8.** FAQ

### Should `Manifest.toml` be checked in to the package?
